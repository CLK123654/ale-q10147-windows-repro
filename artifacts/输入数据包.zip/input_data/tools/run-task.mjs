import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { spawnSync } from "node:child_process";

const root = process.cwd();
const sourcePath = path.join(root, "src", "compile_push_templates.mjs");
const outputRoot = path.join(root, "output");
const outputSource = path.join(outputRoot, "src", "compile_push_templates.mjs");

async function requirePath(relative) {
  try {
    await fs.access(path.join(root, relative));
  } catch {
    throw new Error(`缺少必需材料：${relative}`);
  }
}

async function filesUnder(directory, prefix = "") {
  const result = [];
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) result.push(...await filesUnder(path.join(directory, entry.name), relative));
    else result.push(relative);
  }
  return result.sort();
}

try {
  for (const relative of [
    "templates/push_templates.json",
    "rules/i18n_delivery_policy.json",
    "data/send_queue.csv",
    "src/compile_push_templates.mjs"
  ]) await requirePath(relative);

  await fs.rm(outputRoot, { recursive: true, force: true });
  await fs.mkdir(path.dirname(outputSource), { recursive: true });
  await fs.copyFile(sourcePath, outputSource);
  const child = spawnSync(process.execPath, [outputSource, root, outputRoot], {
    cwd: root,
    encoding: "utf8",
    timeout: 30000,
    windowsHide: true
  });
  if (child.error) throw child.error;
  if (child.status !== 0) throw new Error(child.stderr || child.stdout || `完成版返回${child.status}`);

  const expected = [
    "reports/fallback_decisions.csv",
    "reports/placeholder_mismatches.csv",
    "reports/render_samples.csv",
    "reports/template_locale_matrix.csv",
    "src/compile_push_templates.mjs"
  ];
  const actual = await filesUnder(outputRoot);
  if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error(`交付文件集合不符：${actual.join("|")}`);
  process.stdout.write("推送模板地区编译结果已生成\n");
} catch (error) {
  await fs.rm(outputRoot, { recursive: true, force: true });
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 2;
}
