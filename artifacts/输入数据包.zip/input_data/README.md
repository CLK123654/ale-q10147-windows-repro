# 推送模板国际化编译

本目录保存一批脱敏推送模板、国际化策略和待发送队列。发布值班需要在调用真实推送服务前检查地区覆盖、变量合同、回退结果和最终文本。

templates/push_templates.json按模板和地区保存title与body。rules/i18n_delivery_policy.json定义默认地区、必需地区、回退链、消息部件、变量转义和拦截原因顺序。data/send_queue.csv给出请求地区、变量、用户授权状态及活动状态。starter/compile_push_templates.mjs是待完成源码。

将完成版保存为src/compile_push_templates.mjs，在input_data中运行npm run compile:push。程序应生成以下文件：

output/src/compile_push_templates.mjs
output/reports/template_locale_matrix.csv
output/reports/placeholder_mismatches.csv
output/reports/fallback_decisions.csv
output/reports/render_samples.csv

任务支持Windows11、macOS和Linux，需要Node.js24LTS，不使用第三方npm包。运行期间不连接真实推送、翻译、用户画像或活动管理服务。
