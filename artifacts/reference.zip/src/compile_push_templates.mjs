import fs from 'node:fs/promises';
import path from 'node:path';

const inputRoot = path.resolve(process.argv[2] ?? '.');
const outputRoot = path.resolve(process.argv[3] ?? path.join(inputRoot, 'output'));

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function readJson(relativePath) {
  return JSON.parse(await fs.readFile(path.join(inputRoot, relativePath), 'utf8'));
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') quoted = false;
      else cell += char;
    } else if (char === '"') quoted = true;
    else if (char === ',') {
      row.push(cell);
      cell = '';
    } else if (char === '\n') {
      row.push(cell.replace(/\r$/, ''));
      rows.push(row);
      row = [];
      cell = '';
    } else cell += char;
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ''));
    rows.push(row);
  }
  const headers = rows.shift() ?? [];
  return rows.filter((values) => values.some((value) => value !== '')).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? '']))
  );
}

function csvCell(value) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function toCsv(headers, rows) {
  return `${headers.join(',')}\n${rows.map((row) => headers.map((header) => csvCell(row[header])).join(',')).join('\n')}\n`;
}

function extractPlaceholders(text) {
  const found = new Set();
  let index = 0;
  while (index < text.length) {
    if (text[index] !== '{') {
      index += 1;
      continue;
    }
    let cursor = index + 1;
    let name = '';
    while (cursor < text.length && /[A-Za-z0-9_]/.test(text[cursor])) {
      name += text[cursor];
      cursor += 1;
    }
    if (name) found.add(name);
    let depth = 1;
    cursor = index + 1;
    while (cursor < text.length && depth > 0) {
      if (text[cursor] === '{') depth += 1;
      else if (text[cursor] === '}') depth -= 1;
      cursor += 1;
    }
    index = cursor;
  }
  return [...found].sort();
}

function placeholdersByPart(message, parts) {
  return Object.fromEntries(parts.map((part) => [part, extractPlaceholders(message?.[part] ?? '')]));
}

function placeholderDiff(base, target) {
  return {
    missing: base.filter((item) => !target.includes(item)),
    extra: target.filter((item) => !base.includes(item))
  };
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function renderMessage(text, variables, shouldEscape) {
  let escapedVariableCount = 0;
  let rendered = text.replace(/\{([A-Za-z0-9_]+),\s*plural,\s*one\s*\{([^{}]*)\}\s*other\s*\{([^{}]*)\}\}/g,
    (_match, name, one, other) => {
      const raw = variables[name];
      const branch = Number(raw) === 1 ? one : other;
      return branch.replaceAll('#', String(raw));
    });
  rendered = rendered.replace(/\{([A-Za-z0-9_]+)\}/g, (_match, name) => {
    const raw = variables[name];
    const replacement = shouldEscape ? escapeHtml(raw) : String(raw);
    if (String(raw) !== replacement) escapedVariableCount += 1;
    return replacement;
  });
  return { text: rendered, escapedVariableCount };
}

function fallbackChain(policy, locale) {
  const configured = policy.fallback_chains[locale] ?? [locale, policy.default_locale];
  return configured.includes(policy.default_locale) ? configured : [...configured, policy.default_locale];
}

function resolveLocale(template, requestedLocale, policy) {
  const chain = fallbackChain(policy, requestedLocale);
  const resolvedLocale = chain.find((candidate) => template.messages[candidate]) ?? '';
  return {
    resolved_locale: resolvedLocale,
    resolution: resolvedLocale ? (resolvedLocale === requestedLocale ? 'exact' : 'fallback') : 'missing',
    fallback_path: chain.join('>')
  };
}

const templates = await readJson('templates/push_templates.json');
const policy = await readJson('rules/i18n_delivery_policy.json');
const queue = parseCsv(await fs.readFile(path.join(inputRoot, 'data', 'send_queue.csv'), 'utf8'));
assert(policy.required_message_parts.length > 0, 'required_message_parts不能为空');
assert(new Set(policy.block_reason_order).size === policy.block_reason_order.length, 'block_reason_order不得重复');

const mismatchRows = [];
const mismatchByTemplateLocale = new Map();
for (const [templateId, template] of Object.entries(templates)) {
  const baseMessage = template.messages[policy.default_locale];
  assert(baseMessage, `模板${templateId}缺少默认地区${policy.default_locale}`);
  const base = placeholdersByPart(baseMessage, policy.required_message_parts);
  for (const [locale, message] of Object.entries(template.messages)) {
    if (locale === policy.default_locale) continue;
    const target = placeholdersByPart(message, policy.required_message_parts);
    for (const part of policy.required_message_parts) {
      const diff = placeholderDiff(base[part], target[part]);
      if (!diff.missing.length && !diff.extra.length) continue;
      const mismatchType = diff.missing.length && diff.extra.length
        ? 'missing_and_extra_placeholder'
        : diff.missing.length ? 'missing_placeholder' : 'extra_placeholder';
      mismatchRows.push({
        template_id: templateId,
        locale,
        field: part,
        mismatch_type: mismatchType,
        base_placeholders: base[part].join('|'),
        locale_placeholders: target[part].join('|')
      });
      const key = `${templateId}::${locale}`;
      mismatchByTemplateLocale.set(key, [...(mismatchByTemplateLocale.get(key) ?? []), `${part}:${mismatchType}`]);
    }
  }
}
mismatchRows.sort((a, b) => `${a.template_id}\0${a.locale}\0${a.field}`.localeCompare(`${b.template_id}\0${b.locale}\0${b.field}`));

const matrixRows = [];
for (const [templateId, template] of Object.entries(templates).sort(([left], [right]) => left.localeCompare(right))) {
  for (const requestedLocale of policy.required_locales) {
    const resolved = resolveLocale(template, requestedLocale, policy);
    const mismatchFields = resolved.resolved_locale
      ? (mismatchByTemplateLocale.get(`${templateId}::${resolved.resolved_locale}`) ?? [])
      : [];
    matrixRows.push({
      template_id: templateId,
      requested_locale: requestedLocale,
      resolved_locale: resolved.resolved_locale,
      resolution: resolved.resolution,
      contract_status: mismatchFields.length ? 'placeholder_mismatch' : 'ok',
      mismatch_fields: mismatchFields.join(';'),
      fallback_path: resolved.fallback_path
    });
  }
}

const fallbackRows = [];
const renderRows = [];
for (const job of queue) {
  const template = templates[job.template_id];
  const resolved = template
    ? resolveLocale(template, job.requested_locale, policy)
    : { resolved_locale: '', resolution: 'missing', fallback_path: fallbackChain(policy, job.requested_locale).join('>') };
  let variables = {};
  let selectedMessage = null;
  let mismatchFields = [];
  let missingVariables = [];
  if (template && resolved.resolved_locale) {
    variables = JSON.parse(job.variables_json);
    selectedMessage = template.messages[resolved.resolved_locale];
    mismatchFields = mismatchByTemplateLocale.get(`${job.template_id}::${resolved.resolved_locale}`) ?? [];
    const requiredVariables = [...new Set(policy.required_message_parts.flatMap((part) => extractPlaceholders(selectedMessage[part] ?? '')))].sort();
    missingVariables = requiredVariables.filter((name) => !Object.prototype.hasOwnProperty.call(variables, name));
  }
  const issues = {
    unknown_template: !template ? job.template_id : '',
    locale_unavailable: template && !resolved.resolved_locale ? resolved.fallback_path : '',
    placeholder_contract_mismatch: mismatchFields.length ? mismatchFields.join(';') : '',
    consent_revoked: job.consent_state !== 'active' ? job.consent_state : '',
    campaign_paused: job.campaign_state !== 'live' ? job.campaign_state : '',
    missing_variable: missingVariables.length ? missingVariables.join('|') : ''
  };
  const blockReason = policy.block_reason_order.find((reason) => Boolean(issues[reason])) ?? '';
  const decision = blockReason ? 'blocked' : 'ready';
  if (decision === 'ready') {
    const title = renderMessage(selectedMessage.title, variables, policy.html_escape_variables);
    const body = renderMessage(selectedMessage.body, variables, policy.html_escape_variables);
    renderRows.push({
      job_id: job.job_id,
      template_id: job.template_id,
      locale: resolved.resolved_locale,
      title: title.text,
      body: body.text,
      variable_keys: Object.keys(variables).sort().join('|'),
      escaped_variable_count: title.escapedVariableCount + body.escapedVariableCount
    });
  }
  fallbackRows.push({
    job_id: job.job_id,
    user_id: job.user_id,
    template_id: job.template_id,
    requested_locale: job.requested_locale,
    resolved_locale: resolved.resolved_locale,
    resolution: resolved.resolution,
    fallback_path: resolved.fallback_path,
    decision,
    block_reason: blockReason,
    block_detail: blockReason ? issues[blockReason] : ''
  });
}
fallbackRows.sort((a, b) => a.job_id.localeCompare(b.job_id));
renderRows.sort((a, b) => a.job_id.localeCompare(b.job_id));

await fs.mkdir(path.join(outputRoot, 'reports'), { recursive: true });
await fs.writeFile(path.join(outputRoot, 'reports', 'template_locale_matrix.csv'), toCsv(
  ['template_id', 'requested_locale', 'resolved_locale', 'resolution', 'contract_status', 'mismatch_fields', 'fallback_path'], matrixRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'placeholder_mismatches.csv'), toCsv(
  ['template_id', 'locale', 'field', 'mismatch_type', 'base_placeholders', 'locale_placeholders'], mismatchRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'fallback_decisions.csv'), toCsv(
  ['job_id', 'user_id', 'template_id', 'requested_locale', 'resolved_locale', 'resolution', 'fallback_path', 'decision', 'block_reason', 'block_detail'], fallbackRows
));
await fs.writeFile(path.join(outputRoot, 'reports', 'render_samples.csv'), toCsv(
  ['job_id', 'template_id', 'locale', 'title', 'body', 'variable_keys', 'escaped_variable_count'], renderRows
));
